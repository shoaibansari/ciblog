<!DOCTYPE html>
<html>
<head>
	<title>Ci Blog</title>
	<!-- <link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/litera/bootstrap.min.css"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css">
  
  <!-- Editor plugin cdn-->
  <script src="//cdn.ckeditor.com/4.7.3/standard/ckeditor.js"></script>

</head>
  <body>
      	<nav class="navbar-default">
         <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo base_url(); ?>">ciBlog</a>
          </div>
           <div id="navbar">
             <ul class="nav navbar-nav">
            	 <li><a href="<?php echo base_url(); ?>">Home</a></li>
            	 <li><a href="<?php echo base_url(); ?>about">About</a></li>
               <li><a href="<?php echo base_url(); ?>posts">Blog</a></li>
               <li><a href="<?php echo base_url(); ?>categories">Categories</a></li>
             </ul>
             <ul class="nav navbar-nav navbar-right">
              <?php if(!$this->session->userdata('logged_in')) : ?>
               <li><a href="<?php echo base_url(); ?>users/login">Login</a></li>
               <li><a href="<?php echo base_url(); ?>users/register">Register</a></li>
              <?php endif; ?>
              <?php if($this->session->userdata('logged_in')) : ?>
               <li><a href="<?php echo base_url(); ?>posts/create">Create Post</a></li>
               <li><a href="<?php echo base_url(); ?>categories/create">Create Category</a></li>
               <li><a href="<?php echo base_url(); ?>users/logout">Logout</a></li>
               <?php endif; ?>
             </ul>
          </div>
        </div>
      </nav>

      <div class="container">
        <!-- Flash messages -->
        <?php if($this->session->flashdata('user_registered')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
           <?php echo '<p class="alert alert-success text-center" style="margin-bottom: 0;margin-top: 20px;">'.$this->session->flashdata('user_registered').'</p>'; ?>
            </div>
          </div>
        <?php endif;?>

        <?php if($this->session->flashdata('post_created')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
           <?php echo '<p class="alert alert-success text-center" style="margin-bottom: 0;margin-top: 20px;">'.$this->session->flashdata('post_created').'</p>'; ?>
            </div>
         </div>
        <?php endif;?>

        <?php if($this->session->flashdata('post_updated')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
           <?php echo '<p class="alert alert-success text-center" style="margin-bottom: 0;margin-top: 20px;">'.$this->session->flashdata('post_updated').'</p>'; ?>
            </div>
         </div>
        <?php endif;?>

        <?php if($this->session->flashdata('post_deleted')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
           <?php echo '<p class="alert alert-success text-center" style="margin-bottom: 0;margin-top: 20px;">'.$this->session->flashdata('post_deleted').'</p>'; ?>
            </div>
          </div>
        <?php endif;?>

        <?php if($this->session->flashdata('category_created')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
           <?php echo '<p class="alert alert-success text-center" style="margin-bottom: 0;margin-top: 20px;">'.$this->session->flashdata('category_created').'</p>'; ?>
            </div>
         </div>
        <?php endif;?>

        <?php if($this->session->flashdata('login_failed')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
           <?php echo '<p class="alert alert-danger text-center" style="margin-bottom: 0;margin-top: 20px;">'.$this->session->flashdata('login_failed').'</p>'; ?>
            </div>
         </div>
        <?php endif;?>

        <?php if($this->session->flashdata('user_loggedin')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
               <div class="alert alert-success text-center alert-dismissable fade in" style="margin-bottom: 0;margin-top: 20px;">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                 <?php echo '<p>'.$this->session->flashdata('user_loggedin').'</p>'; ?>
              </div>
            </div>
          </div>
        <?php endif;?>
        
        <?php if($this->session->flashdata('user_loggedout')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
               <div class="alert alert-success text-center alert-dismissable fade in" style="margin-bottom: 0;margin-top: 20px;">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                 <?php echo '<p>'.$this->session->flashdata('user_loggedout').'</p>'; ?>
              </div>
            </div>
          </div>
        <?php endif;?>


        <?php if($this->session->flashdata('category_deleted')) :?>
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
               <div class="alert alert-success text-center alert-dismissable fade in" style="margin-bottom: 0;margin-top: 20px;">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                 <?php echo '<p>'.$this->session->flashdata('category_deleted').'</p>'; ?>
              </div>
            </div>
          </div>
        <?php endif;?>




<script>
  window.setTimeout(function() { $(".alert").fadeIn(); }, 2000);
  window.setTimeout(function() { $(".alert").fadeOut(); }, 2000);
</script> 

   

