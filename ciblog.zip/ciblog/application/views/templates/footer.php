

      </div><!--End container -->

      <footer class="footer">
      	<div class="container">
      	   <p class="text-muted" style="text-align: center;margin-top: 10px;">&copy; ciBlog 2017</p>
      	</div>
      </footer>

      <!-- JavaScript Files here-->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
      <script>
        CKEDITOR.replace( 'editor1' );
      </script>
      <!-- <i class="fa fa-home"></i> -->
<!-- wp_nav_menu(array(
                'theme_location' => 'top-menu',
                'container'      => false,
                'items_wrap'     => '%3$s',
                'depth'          => 1,
              )); -->
   </body>
</html>