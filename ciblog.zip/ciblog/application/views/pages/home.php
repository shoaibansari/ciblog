<h2><?= $title ?></h2>

<?php echo date('j D M  Y -  g:i A',time());?>
