-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2017 at 05:26 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `user_id`, `name`, `created_at`) VALUES
(2, 2, 'Technology', '2017-11-16 08:24:26'),
(4, 3, 'lates Posts', '2017-11-22 10:52:42'),
(7, 1, 'New Year', '2017-11-25 15:06:32'),
(8, 1, 'New Skills', '2017-11-25 15:06:39');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `slug`, `body`, `post_image`, `created_at`) VALUES
(37, 2, 1, 'Post One', 'post-one', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo sapien non purus mollis egestas. Donec aliquam dolor at efficitur pharetra. Morbi ornare libero quis erat imperdiet, a posuere ipsum venenatis. Morbi eget pellentesque ante, eu aliquam velit. Quisque sit amet cursus mi, a aliquam turpis. Cras bibendum justo enim. Quisque non viverra orci. Donec vitae eleifend sem, quis feugiat turpis. Aliquam in blandit sem, non auctor tortor. Nullam ex quam, euismod nec bibendum ut, dapibus non libero. Donec malesuada, dolor nec malesuada pretium, leo lacus tincidunt nisi, quis feugiat mauris est in dolor. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>\r\n\r\n<p>Nullam arcu risus, suscipit tristique placerat a, fermentum id purus. Aliquam in condimentum felis, ut sollicitudin nibh. Quisque mattis nisi at tortor hendrerit, vel ullamcorper felis tincidunt. Sed vehicula gravida magna id vestibulum. Mauris pharetra tempor purus, ut tincidunt nisl. Proin eget urna aliquet, bibendum magna vel, auctor turpis. Vivamus viverra risus lorem, sed fringilla erat pretium in. Donec semper, nunc sit amet ornare semper, diam diam efficitur ante, eget gravida turpis risus id lacus. Cras a lectus ante. Vestibulum sit amet eros libero.</p>\r\n', 'noimage.png', '2017-11-25 15:42:27'),
(38, 8, 1, 'Post Two', 'post-two', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo sapien non purus mollis egestas. Donec aliquam dolor at efficitur pharetra. Morbi ornare libero quis erat imperdiet, a posuere ipsum venenatis. Morbi eget pellentesque ante, eu aliquam velit. Quisque sit amet cursus mi, a aliquam turpis. Cras bibendum justo enim. Quisque non viverra orci. Donec vitae eleifend sem, quis feugiat turpis. Aliquam in blandit sem, non auctor tortor. Nullam ex quam, euismod nec bibendum ut, dapibus non libero. Donec malesuada, dolor nec malesuada pretium, <strong>leo lacus tincidunt nisi, quis feugiat mauris est in dolor. Interdum et malesuada fames ac ante ipsum primis in faucibus.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n', 'social_default_logo-1481777.png', '2017-11-25 15:43:09'),
(39, 8, 1, 'Post Three', 'post-three', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <em>Sed commodo sapien non purus mollis egestas</em>. Donec aliquam dolor at efficitur pharetra. Morbi ornare libero quis erat imperdiet, a posuere ipsum venenatis. Morbi eget pellentesque <strong>ante, eu aliquam velit. Quisque sit amet cursus mi, a aliquam turpi</strong>s. Cras bibendum justo enim. Quisque non viverra orci. Donec vitae eleifend sem, quis feugiat turpis. Aliquam in blandit sem, non auctor tortor. Nullam ex quam, euismod nec bibendum ut, dapibus non libero. Donec malesuada, dolor nec malesuada pretium,</p>\r\n', 'download.jpg', '2017-11-25 15:43:55'),
(40, 4, 1, 'Post Four', 'post-four', '<p><strong>Lorem ipsum dolor sit amet</strong>, consectetur adipiscing elit. Sed commodo sapien non purus mollis egestas. Donec aliquam dolor at efficitur pharetra. Morbi ornare libero quis erat imperdiet, a posuere ipsum venenatis. Morbi eget pellentesque ante, eu aliquam velit. Quisque sit amet cursus mi, a aliquam turpis. Cras bibendum justo enim. Quisque non viverra orci. Donec vitae&nbsp;</p>\r\n', 'noimage.png', '2017-11-25 15:44:44'),
(42, 8, 1, 'Post Seven', 'post-seven', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent porttitor nibh eget sapien lobortis egestas. Sed maximus, mauris quis maximus pellentesque, augue lorem malesuada lectus, eget luctus sapien sapien pretium odio. Nullam cursus varius magna at condimentum. In maximus bibendum dolor sit amet laoreet. Pellentesque et est quis nunc facilisis gravida at et neque. Nulla interdum, orci vitae suscipit porttitor, lacus dolor placerat risus, sed blandit ante elit sed tortor. Nunc ligula arcu, commodo at risus a, accumsan vehicula purus. Sed ornare, lorem at congue rutrum, lacus libero suscipit quam, vitae elementum orci elit at justo.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent porttitor nibh eget sapien lobortis egestas. Sed maximus, mauris quis maximus pellentesque, augue lorem malesuada lectus, eget luctus sapien sapien pretium odio. Nullam cursus varius magna at condimentum. In maximus bibendum dolor sit amet laoreet. Pellentesque et est quis nunc facilisis gravida at et neque. Nulla interdum, orci vitae suscipit porttitor, lacus dolor placerat risus, sed blandit ante elit sed tortor. Nunc ligula arcu, commodo at risus a, accumsan vehicula purus. Sed ornare, lorem at congue rutrum, lacus libero suscipit quam, vitae elementum orci elit at justo.</p>\r\n', 'yahoo_logo_large-100044513-large.jpg', '2017-11-25 16:20:50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `zipcode`, `email`, `username`, `password`, `register_date`) VALUES
(1, 'Shoaib', '021544', 'shoaib@gmail.com', 'Shoaib Ansari', '81dc9bdb52d04dc20036dbd8313ed055', '2017-11-23 16:11:24'),
(2, 'Huzail', '25250', 'huzail@gmail.com', 'Huzail Ansari', '81dc9bdb52d04dc20036dbd8313ed055', '2017-11-24 07:01:57'),
(3, 'Saima', '21166', 'saima@gmail.com', 'Saima Ansari', '81dc9bdb52d04dc20036dbd8313ed055', '2017-11-24 07:05:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
